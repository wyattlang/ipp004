from globals import exam_scores

